-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.1.72-community - MySQL Community Server (GPL)
-- Server OS:                    Win32
-- HeidiSQL Version:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for jerrymouseteam
CREATE DATABASE IF NOT EXISTS `jerrymouseteam` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `jerrymouseteam`;

-- Dumping structure for table jerrymouseteam.address
CREATE TABLE IF NOT EXISTS `address` (
  `address_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `address_line1` varchar(255) DEFAULT NULL,
  `address_line2` varchar(255) DEFAULT NULL,
  `address_line3` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `state` varchar(255) DEFAULT NULL,
  `updated_date` datetime NOT NULL,
  `zipcode` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`address_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Dumping data for table jerrymouseteam.address: ~4 rows (approximately)
DELETE FROM `address`;
/*!40000 ALTER TABLE `address` DISABLE KEYS */;
INSERT INTO `address` (`address_id`, `address_line1`, `address_line2`, `address_line3`, `city`, `country`, `created_date`, `state`, `updated_date`, `zipcode`) VALUES
	(1, 'addressLine1', 'addressLine2', 'addressLine3', 'city', 'country', '2018-07-31 21:28:45', 'state', '2018-08-02 00:37:14', 'zipCode'),
	(2, 'SUKH-Shanti CHS LTD', NULL, NULL, 'Mumbai', 'INDIA', '2018-07-31 21:35:19', 'MH', '2018-07-31 21:35:19', '400065'),
	(3, 'SUKH-Shanti CHS LTD', NULL, NULL, 'Mumbai', 'INDIA', '2018-08-01 20:26:57', 'MH', '2018-08-01 20:26:57', '400065'),
	(4, 'addressLine1', 'addressLine2', 'addressLine3', 'city', 'country', '2018-08-02 00:06:43', 'state', '2018-08-02 00:06:43', 'zipCode'),
	(5, 'Sukh-Shanti', '', '', 'Mumbai', 'India', '2018-08-15 10:06:22', 'Maharashatra', '2018-08-15 10:06:22', '123456789');
/*!40000 ALTER TABLE `address` ENABLE KEYS */;

-- Dumping structure for table jerrymouseteam.clients
CREATE TABLE IF NOT EXISTS `clients` (
  `client_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `is_active` bit(1) NOT NULL,
  `client_name` varchar(255) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `updated_date` datetime NOT NULL,
  PRIMARY KEY (`client_id`),
  UNIQUE KEY `UK759udbd1akn2tuipnp89ubjl6` (`client_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table jerrymouseteam.clients: ~2 rows (approximately)
DELETE FROM `clients`;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` (`client_id`, `is_active`, `client_name`, `created_date`, `updated_date`) VALUES
	(1, b'0', 'AXIS', '2018-07-29 01:28:29', '2018-08-04 21:04:45'),
	(2, b'1', 'FNBO', '2018-07-29 01:29:44', '2018-07-29 01:29:44');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;

-- Dumping structure for table jerrymouseteam.grades
CREATE TABLE IF NOT EXISTS `grades` (
  `grade_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `is_active` bit(1) NOT NULL,
  `created_date` datetime NOT NULL,
  `grade_desc` varchar(255) DEFAULT NULL,
  `grade_name` varchar(255) DEFAULT NULL,
  `updated_date` datetime NOT NULL,
  PRIMARY KEY (`grade_id`),
  UNIQUE KEY `UKoimhh5v4bseu9oqiv8gm4lwoa` (`grade_name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- Dumping data for table jerrymouseteam.grades: ~7 rows (approximately)
DELETE FROM `grades`;
/*!40000 ALTER TABLE `grades` DISABLE KEYS */;
INSERT INTO `grades` (`grade_id`, `is_active`, `created_date`, `grade_desc`, `grade_name`, `updated_date`) VALUES
	(1, b'0', '2018-06-30 19:30:35', 'Grade 1 Desc', 'Grade 1', '2018-06-30 19:30:35'),
	(2, b'1', '2018-06-30 19:35:15', 'Grade 3 Desc', 'Grade 3', '2018-06-30 19:35:15'),
	(3, b'1', '2018-06-30 19:35:15', 'Grade 2 Desc', 'Grade 2', '2018-06-30 19:35:15'),
	(4, b'1', '2018-06-30 19:43:18', 'Grade 4 Desc', 'Grade 4', '2018-06-30 19:43:18'),
	(5, b'1', '2018-06-30 19:43:18', 'Grade 5 Desc', 'Grade 5', '2018-06-30 19:43:18'),
	(6, b'1', '2018-06-30 19:52:31', 'Grade 6 Desc', 'Grade 6', '2018-06-30 19:52:31'),
	(7, b'1', '2018-08-15 09:03:20', 'Grade 10-1 Desc', 'Grade 10-1', '2018-08-15 09:03:20');
/*!40000 ALTER TABLE `grades` ENABLE KEYS */;

-- Dumping structure for table jerrymouseteam.grade_units
CREATE TABLE IF NOT EXISTS `grade_units` (
  `grade_id` bigint(20) NOT NULL,
  `unit_id` bigint(20) NOT NULL,
  PRIMARY KEY (`grade_id`,`unit_id`),
  KEY `FKdfe2sjjyudckgulaa9ebjvtu5` (`unit_id`),
  CONSTRAINT `FK574bxqhkk99g46h20h6sx43np` FOREIGN KEY (`grade_id`) REFERENCES `grades` (`grade_id`),
  CONSTRAINT `FKdfe2sjjyudckgulaa9ebjvtu5` FOREIGN KEY (`unit_id`) REFERENCES `units` (`unit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table jerrymouseteam.grade_units: ~6 rows (approximately)
DELETE FROM `grade_units`;
/*!40000 ALTER TABLE `grade_units` DISABLE KEYS */;
INSERT INTO `grade_units` (`grade_id`, `unit_id`) VALUES
	(1, 2),
	(1, 3),
	(6, 4),
	(6, 5),
	(7, 6),
	(7, 7);
/*!40000 ALTER TABLE `grade_units` ENABLE KEYS */;

-- Dumping structure for table jerrymouseteam.items
CREATE TABLE IF NOT EXISTS `items` (
  `item_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `is_active` bit(1) NOT NULL,
  `created_date` datetime NOT NULL,
  `item_desc` varchar(255) DEFAULT NULL,
  `item_name` varchar(255) DEFAULT NULL,
  `updated_date` datetime NOT NULL,
  PRIMARY KEY (`item_id`),
  UNIQUE KEY `UKaovopo49s1p2ttra9i5fqmtve` (`item_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table jerrymouseteam.items: ~3 rows (approximately)
DELETE FROM `items`;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` (`item_id`, `is_active`, `created_date`, `item_desc`, `item_name`, `updated_date`) VALUES
	(1, b'1', '2018-06-30 19:35:15', 'Item 1 Desc', 'Item 1', '2018-06-30 19:35:15'),
	(2, b'1', '2018-06-30 19:43:18', 'Item 2 Desc', 'Item 2', '2018-06-30 19:43:18'),
	(3, b'1', '2018-08-15 09:03:20', 'Item 10 Desc', 'Item 10', '2018-08-15 09:03:20');
/*!40000 ALTER TABLE `items` ENABLE KEYS */;

-- Dumping structure for table jerrymouseteam.item_grades
CREATE TABLE IF NOT EXISTS `item_grades` (
  `item_id` bigint(20) NOT NULL,
  `grade_id` bigint(20) NOT NULL,
  PRIMARY KEY (`item_id`,`grade_id`),
  KEY `FKmag8dx20s6req9n99jr2b6ni5` (`grade_id`),
  CONSTRAINT `FK4g7y404hq3aqesaginoe5vkpc` FOREIGN KEY (`item_id`) REFERENCES `items` (`item_id`),
  CONSTRAINT `FKmag8dx20s6req9n99jr2b6ni5` FOREIGN KEY (`grade_id`) REFERENCES `grades` (`grade_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table jerrymouseteam.item_grades: ~5 rows (approximately)
DELETE FROM `item_grades`;
/*!40000 ALTER TABLE `item_grades` DISABLE KEYS */;
INSERT INTO `item_grades` (`item_id`, `grade_id`) VALUES
	(1, 2),
	(1, 3),
	(2, 4),
	(2, 5),
	(3, 7);
/*!40000 ALTER TABLE `item_grades` ENABLE KEYS */;

-- Dumping structure for table jerrymouseteam.notes
CREATE TABLE IF NOT EXISTS `notes` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- Dumping data for table jerrymouseteam.notes: ~4 rows (approximately)
DELETE FROM `notes`;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
INSERT INTO `notes` (`id`, `content`, `created_at`, `title`, `updated_at`) VALUES
	(1, 'Test 3', '2018-06-23 15:13:44', 'Test 3', '2018-06-23 15:19:36'),
	(4, 'NOte 100', '2018-06-23 15:41:59', 'NOte 100', '2018-06-23 15:41:59'),
	(5, 'Test Content6', '2018-06-24 11:32:17', 'Test6', '2018-06-24 11:32:17'),
	(6, 'Test Content6', '2018-06-24 11:35:41', 'Test7', '2018-06-24 11:35:41');
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;

-- Dumping structure for table jerrymouseteam.partners
CREATE TABLE IF NOT EXISTS `partners` (
  `partner_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `is_active` bit(1) NOT NULL,
  `created_date` datetime NOT NULL,
  `partner_name` varchar(255) DEFAULT NULL,
  `updated_date` datetime NOT NULL,
  PRIMARY KEY (`partner_id`),
  UNIQUE KEY `UKcv5cenrt5goits0y9f55f3ulk` (`partner_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table jerrymouseteam.partners: ~1 rows (approximately)
DELETE FROM `partners`;
/*!40000 ALTER TABLE `partners` DISABLE KEYS */;
INSERT INTO `partners` (`partner_id`, `is_active`, `created_date`, `partner_name`, `updated_date`) VALUES
	(1, b'1', '2018-07-03 20:50:38', 'US BANK', '2018-07-03 20:50:38');
/*!40000 ALTER TABLE `partners` ENABLE KEYS */;

-- Dumping structure for table jerrymouseteam.roles
CREATE TABLE IF NOT EXISTS `roles` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `is_active` bit(1) NOT NULL,
  `created_date` datetime NOT NULL,
  `role_name` varchar(255) DEFAULT NULL,
  `updated_date` datetime NOT NULL,
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `UK716hgxp60ym1lifrdgp67xt5k` (`role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table jerrymouseteam.roles: ~2 rows (approximately)
DELETE FROM `roles`;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`role_id`, `is_active`, `created_date`, `role_name`, `updated_date`) VALUES
	(1, b'1', '2018-07-29 01:28:16', 'ADMIN', '2018-07-29 01:28:16'),
	(2, b'1', '2018-07-29 01:29:58', 'USER', '2018-07-29 01:29:58');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;

-- Dumping structure for table jerrymouseteam.status
CREATE TABLE IF NOT EXISTS `status` (
  `status_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_date` datetime NOT NULL,
  `status_desc` varchar(255) DEFAULT NULL,
  `status_name` varchar(255) DEFAULT NULL,
  `updated_date` datetime NOT NULL,
  PRIMARY KEY (`status_id`),
  UNIQUE KEY `UKikty98aye7nunxe4f25a39efl` (`status_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table jerrymouseteam.status: ~1 rows (approximately)
DELETE FROM `status`;
/*!40000 ALTER TABLE `status` DISABLE KEYS */;
INSERT INTO `status` (`status_id`, `created_date`, `status_desc`, `status_name`, `updated_date`) VALUES
	(1, '2018-07-01 01:00:01', 'AUTHORIZED', 'AUTHORIZED', '2018-07-01 01:00:01');
/*!40000 ALTER TABLE `status` ENABLE KEYS */;

-- Dumping structure for table jerrymouseteam.units
CREATE TABLE IF NOT EXISTS `units` (
  `unit_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `is_active` bit(1) NOT NULL,
  `created_date` datetime NOT NULL,
  `unit_desc` varchar(255) DEFAULT NULL,
  `unit_name` varchar(255) DEFAULT NULL,
  `updated_date` datetime NOT NULL,
  PRIMARY KEY (`unit_id`),
  UNIQUE KEY `UK525csmemmgtoicjcfhcpf3pk0` (`unit_name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- Dumping data for table jerrymouseteam.units: ~7 rows (approximately)
DELETE FROM `units`;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
INSERT INTO `units` (`unit_id`, `is_active`, `created_date`, `unit_desc`, `unit_name`, `updated_date`) VALUES
	(1, b'0', '2018-06-30 12:59:14', 'Unit Teset  Desc', 'Unit 1', '2018-06-30 13:06:02'),
	(2, b'0', '2018-06-30 19:30:35', 'Unit 2 Desc', 'Unit 2', '2018-06-30 19:30:35'),
	(3, b'0', '2018-06-30 19:30:35', 'Unit 3 Desc', 'Unit 3', '2018-06-30 19:30:35'),
	(4, b'1', '2018-06-30 19:52:31', 'Unit 4 Desc', 'Unit 4', '2018-06-30 19:52:31'),
	(5, b'1', '2018-06-30 19:52:31', 'Unit 5 Desc', 'Unit 5', '2018-06-30 19:52:31'),
	(6, b'1', '2018-08-15 09:03:20', 'Unit 10-1 Desc', 'Unit 10-1', '2018-08-15 09:03:20'),
	(7, b'1', '2018-08-15 09:03:20', 'Unit 10-2 Desc', 'Unit 10-2', '2018-08-15 09:03:20');
/*!40000 ALTER TABLE `units` ENABLE KEYS */;

-- Dumping structure for table jerrymouseteam.users
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `is_active` bit(1) NOT NULL,
  `created_date` datetime NOT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `mobile_number` varchar(255) DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `updated_date` datetime NOT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `address_id` bigint(20) DEFAULT NULL,
  `client_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `FKditu6lr4ek16tkxtdsne0gxib` (`address_id`),
  KEY `FKqvykjc6027qa8n5es37omu3xs` (`client_id`),
  CONSTRAINT `FKditu6lr4ek16tkxtdsne0gxib` FOREIGN KEY (`address_id`) REFERENCES `address` (`address_id`),
  CONSTRAINT `FKqvykjc6027qa8n5es37omu3xs` FOREIGN KEY (`client_id`) REFERENCES `clients` (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- Dumping data for table jerrymouseteam.users: ~5 rows (approximately)
DELETE FROM `users`;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`user_id`, `is_active`, `created_date`, `email_id`, `first_name`, `last_name`, `middle_name`, `mobile_number`, `phone_number`, `updated_date`, `user_name`, `user_password`, `address_id`, `client_id`) VALUES
	(2, b'1', '2018-07-31 21:15:33', NULL, NULL, NULL, NULL, NULL, NULL, '2018-07-31 21:15:33', 'Vivek', 'Test@1323424', NULL, 2),
	(5, b'1', '2018-07-31 21:26:52', 'test@gmail.com', 'Harshad', 'Gaikwad', NULL, '7208733078', '123456799', '2018-07-31 21:26:52', 'harshag', 'Test@1323424', 2, 2),
	(6, b'1', '2018-07-31 21:28:44', 'test@gmail.com', 'Harshad', 'Gaikwad', NULL, '7208733078', '123456799', '2018-07-31 21:28:44', 'harshag', 'Test@1323424', 1, 2),
	(7, b'1', '2018-07-31 21:35:19', 'test@gmail.com', 'Harshad', 'Gaikwad', NULL, '7208733078', '123456799', '2018-07-31 21:35:19', 'harshag123', 'Test@1323424', 2, 2),
	(8, b'1', '2018-08-01 20:26:57', 'test@gmail.com', 'Harshad', 'Gaikwad', NULL, '7208733078', '123456799', '2018-08-01 20:26:57', 'harshag', 'Test@1323424', 3, 2);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

-- Dumping structure for table jerrymouseteam.user_roles
CREATE TABLE IF NOT EXISTS `user_roles` (
  `user_id` bigint(20) NOT NULL,
  `role_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `FKh8ciramu9cc9q3qcqiv4ue8a6` (`role_id`),
  CONSTRAINT `FKh8ciramu9cc9q3qcqiv4ue8a6` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`),
  CONSTRAINT `FKhfh9dx7w3ubf1co1vdev94g3f` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table jerrymouseteam.user_roles: ~10 rows (approximately)
DELETE FROM `user_roles`;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` (`user_id`, `role_id`) VALUES
	(2, 1),
	(5, 1),
	(6, 1),
	(7, 1),
	(8, 1),
	(2, 2),
	(5, 2),
	(6, 2),
	(7, 2),
	(8, 2);
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;

-- Dumping structure for table jerrymouseteam.vendors
CREATE TABLE IF NOT EXISTS `vendors` (
  `vendor_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `is_active` bit(1) NOT NULL,
  `bank_account_number` varchar(255) DEFAULT NULL,
  `bank_branch_ifsc` varchar(255) DEFAULT NULL,
  `bank_branch_name` varchar(255) DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `contact_person_alternate_phone_no` varchar(255) DEFAULT NULL,
  `contact_person_email` varchar(255) DEFAULT NULL,
  `contact_person_mobile` varchar(255) DEFAULT NULL,
  `contact_person_name` varchar(255) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `service_rendered_goods_supplied` varchar(255) DEFAULT NULL,
  `updated_date` datetime NOT NULL,
  `vendor_gst_number` varchar(255) DEFAULT NULL,
  `vendor_name` varchar(255) DEFAULT NULL,
  `vendor_nick_name` varchar(255) DEFAULT NULL,
  `address_id` bigint(20) DEFAULT NULL,
  `vendortype_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`vendor_id`),
  UNIQUE KEY `UKbgcli20vynpaq2ca2h8twxq63` (`vendor_name`),
  KEY `FKkc4ifc5duvv07iabgfuhe6l1u` (`address_id`),
  KEY `FKqbaiuidf5eielmtp1n7d6cdit` (`vendortype_id`),
  CONSTRAINT `FKkc4ifc5duvv07iabgfuhe6l1u` FOREIGN KEY (`address_id`) REFERENCES `address` (`address_id`),
  CONSTRAINT `FKqbaiuidf5eielmtp1n7d6cdit` FOREIGN KEY (`vendortype_id`) REFERENCES `vendor_types` (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table jerrymouseteam.vendors: ~1 rows (approximately)
DELETE FROM `vendors`;
/*!40000 ALTER TABLE `vendors` DISABLE KEYS */;
INSERT INTO `vendors` (`vendor_id`, `is_active`, `bank_account_number`, `bank_branch_ifsc`, `bank_branch_name`, `bank_name`, `contact_person_alternate_phone_no`, `contact_person_email`, `contact_person_mobile`, `contact_person_name`, `created_date`, `service_rendered_goods_supplied`, `updated_date`, `vendor_gst_number`, `vendor_name`, `vendor_nick_name`, `address_id`, `vendortype_id`) VALUES
	(1, b'1', '', '', '', '', '', '', '', '', '2018-07-01 00:40:37', NULL, '2018-07-01 00:40:37', '123466', 'Vendor1', 'Vendor1', 1, 3),
	(2, b'1', '', '', '', '', '', '', '', '', '2018-08-15 10:06:22', NULL, '2018-08-15 10:06:22', '123466', 'V 501', 'VT 501', 5, 5);
/*!40000 ALTER TABLE `vendors` ENABLE KEYS */;

-- Dumping structure for table jerrymouseteam.vendor_types
CREATE TABLE IF NOT EXISTS `vendor_types` (
  `type_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `is_active` bit(1) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `type_desc` varchar(255) DEFAULT NULL,
  `type_name` varchar(255) DEFAULT NULL,
  `updated_date` datetime NOT NULL,
  PRIMARY KEY (`type_id`),
  UNIQUE KEY `UKouv1on478g8gqr9h0lkk23626` (`type_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Dumping data for table jerrymouseteam.vendor_types: ~3 rows (approximately)
DELETE FROM `vendor_types`;
/*!40000 ALTER TABLE `vendor_types` DISABLE KEYS */;
INSERT INTO `vendor_types` (`type_id`, `is_active`, `created_date`, `type_desc`, `type_name`, `updated_date`) VALUES
	(1, b'1', '2018-06-24 12:22:28', 'Goods', 'Goods', '2018-06-24 12:22:28'),
	(2, b'1', '2018-06-29 01:12:10', 'Goods2', 'Goods2', '2018-06-29 01:12:10'),
	(3, b'1', '2018-07-01 00:40:37', 'Vt 200', 'VT 200', '2018-07-01 00:40:37'),
	(5, b'1', '2018-08-15 10:06:22', 'VT 501', 'VT 501', '2018-08-15 10:06:22');
/*!40000 ALTER TABLE `vendor_types` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
