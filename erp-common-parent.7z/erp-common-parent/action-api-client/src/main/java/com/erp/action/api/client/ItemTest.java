package com.erp.action.api.client;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.erp.action.api.model.Item;
import com.erp.common.wrapper.model.GradeWrapper;
import com.erp.common.wrapper.model.ItemWrapper;
import com.erp.common.wrapper.model.UnitWrapper;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ItemTest {
	
	public static ItemWrapper getItemById(long id) throws JsonParseException, JsonMappingException, IOException {
		final String uri = "http://localhost:8088/api/items/"+id;

		RestTemplate restTemplate = new RestTemplate();
		String result = restTemplate.getForObject(uri, String.class);
		
		System.out.println(result);

		ObjectMapper objectMapper = new ObjectMapper();
		ItemWrapper navigation = objectMapper.readValue(result,
				objectMapper.getTypeFactory().constructType(ItemWrapper.class));

		System.out.println(navigation);
		return navigation;


	}
	
	private static Set<ItemWrapper> getAllItems() throws JsonParseException, JsonMappingException, IOException
	{
		RestTemplate restTemplate = new RestTemplate();
		final String uri = "http://localhost:8088/api/items";
		
		// Try 1
		
		/*RestTemplate restTemplate = new RestTemplate();
		String result = restTemplate.getForObject(uri, String.class);*/
		
		
		// Try 2
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		
		ResponseEntity<String> result = restTemplate.exchange(uri, HttpMethod.GET, entity, String.class);
		
		System.out.println(result.getStatusCodeValue());
		System.out.println(result.getBody());
		

		ObjectMapper objectMapper = new ObjectMapper();
		Set<ItemWrapper> navigation = objectMapper.readValue(result.getBody(),
				objectMapper.getTypeFactory().constructCollectionType(Set.class, ItemWrapper.class));

		return navigation;
	}
	
	public static void customHeader()
	{
		final String uri = "http://localhost:8088/api/items";
		
		RestTemplate restTemplate = new RestTemplate();
		
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		
		ResponseEntity<String> result = restTemplate.exchange(uri, HttpMethod.GET, entity, String.class);
		
		System.out.println(result);
	}
	
	public static void createItem()
	{
		final String uri = "http://localhost:8088/api/items";
		
		UnitWrapper unit1=new UnitWrapper();
		unit1.setUnitName("Unit 10-1");
		unit1.setActive(true);
		unit1.setUnitDesc("Unit 10-1 Desc");
		
		UnitWrapper unit2=new UnitWrapper();
		unit2.setUnitName("Unit 10-2");
		unit2.setActive(true);
		unit2.setUnitDesc("Unit 10-2 Desc");
		
		Set<UnitWrapper> units=new HashSet<>();
		units.add(unit1);
		units.add(unit2);
		
		GradeWrapper grade1=new GradeWrapper();
		grade1.setGradeName("Grade 10-1");
		grade1.setActive(true);
		grade1.setGradeDesc("Grade 10-1 Desc");
		grade1.setUnits(units);
		
		/*GradeWrapper grade2=new GradeWrapper();
		grade2.setGradeName("Grade 10-2");
		grade2.setActive(true);
		grade2.setGradeDesc("Grade 10-2 Desc");*/
		
		Set<GradeWrapper> grades=new HashSet<>();
		grades.add(grade1);
		//grades.add(grade2);

		ItemWrapper item = new ItemWrapper();
		item.setItemName("Item 10");
		item.setItemDesc("Item 10 Desc");
		item.setActive(true);
		item.setGrades(grades);
		
		RestTemplate restTemplate = new RestTemplate();
		ItemWrapper result = restTemplate.postForObject( uri, item, ItemWrapper.class);

		System.out.println(result);
	}
	
	private static void updateItem()
	{
		final String uri = "http://localhost:8088/api/items/{id}";
		
		Map<String, String> params = new HashMap<String, String>();
		params.put("id", "1");
		
		Item Item = new Item();
		Item.setItemName("Item 1");
		Item.setItemDesc("Item Teset  Desc");
		
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.put ( uri, Item, params);
	}
	
	private static void deleteItem()
	{
		final String uri = "http://localhost:8088/api/items/{id}";
		
		Map<String, String> params = new HashMap<String, String>();
		params.put("id", "1");
		
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.delete ( uri,  params );
	}

	public static void main(String[] args) throws JsonParseException, JsonMappingException, IOException {
		//createItem();
		
		//System.out.println(getAllItems());
		
		System.out.println(getItemById(3));

	}

}
