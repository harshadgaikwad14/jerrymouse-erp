package com.erp.action.api.client;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.erp.action.api.model.Unit;
import com.erp.common.wrapper.model.RoleWrapper;
import com.erp.common.wrapper.model.UnitWrapper;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class UnitTest {
	
	public static UnitWrapper getUnitById(long id) throws JsonParseException, JsonMappingException, IOException {
		final String uri = "http://localhost:8088/api/units/"+id;

		RestTemplate restTemplate = new RestTemplate();
		String result = restTemplate.getForObject(uri, String.class);

		System.out.println(result);
		ObjectMapper objectMapper = new ObjectMapper();
		UnitWrapper navigation = objectMapper.readValue(result,
				objectMapper.getTypeFactory().constructType(UnitWrapper.class));

		System.out.println(navigation);
		return navigation;

	}
	
	private static Set<UnitWrapper> getAllUnits() throws JsonParseException, JsonMappingException, IOException
	{
		RestTemplate restTemplate = new RestTemplate();
		final String uri = "http://localhost:8088/api/units";
		
		// Try 1
		
		/*RestTemplate restTemplate = new RestTemplate();
		String result = restTemplate.getForObject(uri, String.class);*/
		
		
		// Try 2
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		
		ResponseEntity<String> result = restTemplate.exchange(uri, HttpMethod.GET, entity, String.class);
		
		System.out.println(result.getStatusCodeValue());
		System.out.println(result.getBody());
		
		ObjectMapper objectMapper = new ObjectMapper();
		Set<UnitWrapper> navigation = objectMapper.readValue(result.getBody(),
				objectMapper.getTypeFactory().constructCollectionType(Set.class, UnitWrapper.class));

		return navigation;
	}
	
	public static void customHeader()
	{
		final String uri = "http://localhost:8088/api/units";
		
		RestTemplate restTemplate = new RestTemplate();
		
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		
		ResponseEntity<String> result = restTemplate.exchange(uri, HttpMethod.GET, entity, String.class);
		
		System.out.println(result);
	}
	
	public static void createNote()
	{
		final String uri = "http://localhost:8088/api/units";

		Unit unit = new Unit();
		unit.setUnitName("Unit 1");
		unit.setUnitDesc("Unit 1 Desc");
		RestTemplate restTemplate = new RestTemplate();
		Unit result = restTemplate.postForObject( uri, unit, Unit.class);

		System.out.println(result);
	}
	
	private static void updateNote()
	{
		final String uri = "http://localhost:8088/api/units/{id}";
		
		Map<String, String> params = new HashMap<String, String>();
		params.put("id", "1");
		
		Unit unit = new Unit();
		unit.setUnitName("Unit 1");
		unit.setUnitDesc("Unit Teset  Desc");
		
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.put ( uri, unit, params);
	}
	
	private static void deleteNote()
	{
		final String uri = "http://localhost:8088/api/units/{id}";
		
		Map<String, String> params = new HashMap<String, String>();
		params.put("id", "1");
		
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.delete ( uri,  params );
	}

	public static void main(String[] args) throws JsonParseException, JsonMappingException, IOException {
		
		System.out.println(getAllUnits());
		//System.out.println(getUnitById(1));
		

	}

}
