package com.erp.action.api.client;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.erp.action.api.model.Vendor;
import com.erp.common.wrapper.model.AddressWrapper;
import com.erp.common.wrapper.model.VendorTypeWrapper;
import com.erp.common.wrapper.model.VendorWrapper;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class VendorTest {
	
	public static void getVendorById(long id) {
		final String uri = "http://localhost:8088/api/vendors/"+id;

		RestTemplate restTemplate = new RestTemplate();
		String result = restTemplate.getForObject(uri, String.class);

		System.out.println(result);

	}
	
	private static Set<VendorWrapper> getAllVendors() throws JsonParseException, JsonMappingException, IOException
	{
		RestTemplate restTemplate = new RestTemplate();
		final String uri = "http://localhost:8088/api/vendors";
		
		// Try 1
		
		/*RestTemplate restTemplate = new RestTemplate();
		String result = restTemplate.getForObject(uri, String.class);*/
		
		
		// Try 2
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		
		ResponseEntity<String> result = restTemplate.exchange(uri, HttpMethod.GET, entity, String.class);
		
		System.out.println(result.getStatusCodeValue());
		System.out.println(result.getBody());
		
		ObjectMapper objectMapper = new ObjectMapper();

		Set<VendorWrapper> navigation = objectMapper.readValue(result.getBody(),
				objectMapper.getTypeFactory().constructCollectionType(Set.class, VendorWrapper.class));

		return navigation;
	}
	
	public static void customHeader()
	{
		final String uri = "http://localhost:8088/api/vendors";
		
		RestTemplate restTemplate = new RestTemplate();
		
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		
		ResponseEntity<String> result = restTemplate.exchange(uri, HttpMethod.GET, entity, String.class);
		
		System.out.println(result);
	}
	
	public static VendorWrapper createVendor()
	{
		final String uri = "http://localhost:8088/api/vendors";
		
		AddressWrapper a=new AddressWrapper();
		a.setAddressLine1("Sukh-Shanti");
		a.setAddressLine2("");
		a.setAddressLine3("");
		a.setCity("Mumbai");
		a.setCountry("India");
		a.setState("Maharashatra");
		a.setZipCode("123456789");
		
		
		
		VendorTypeWrapper vt=new VendorTypeWrapper();
		vt.setActive(true);
		vt.setTypeName("VT 501");
		vt.setTypeDesc("VT 501");

		VendorWrapper vendor = new VendorWrapper();
		vendor.setActive(true);
		vendor.setAddress(a);
		vendor.setVendorName("V 501");
		vendor.setVendorType(vt);
		vendor.setVendorNickName("VT 501");
		vendor.setVendorGstNumber("123466");
		vendor.setContactPersonAlternatePhoneNo("");
		vendor.setContactPersonEmail("");
		vendor.setContactPersonMobile("");
		vendor.setContactPersonName("");
		vendor.setBankAccountNumber("");
		vendor.setBankBranchIfsc("");
		vendor.setBankBranchName("");
		vendor.setBankName("");
		
		
		
		RestTemplate restTemplate = new RestTemplate();
		VendorWrapper result = restTemplate.postForObject( uri, vendor, VendorWrapper.class);

		System.out.println(result);
		
		return result;
	}
	
	private static void updateVendor()
	{
		final String uri = "http://localhost:8088/api/vendors/{id}";
		
		Map<String, String> params = new HashMap<String, String>();
		params.put("id", "1");
		
		
		
		Vendor Vendor = new Vendor();
		
		
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.put ( uri, Vendor, params);
	}
	
	private static void deleteVendor()
	{
		final String uri = "http://localhost:8088/api/vendors/{id}";
		
		Map<String, String> params = new HashMap<String, String>();
		params.put("id", "1");
		
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.delete ( uri,  params );
	}

	public static void main(String[] args) throws JsonParseException, JsonMappingException, IOException {
	
		System.out.println(createVendor());
		System.out.println(getAllVendors());

	}

}
