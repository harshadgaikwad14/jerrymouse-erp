package com.erp.common.wrapper.model;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by Harshad on 24/06/2018.
 */

public class ItemWrapper implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private long id;

	private String itemName;

	private String itemDesc;

	private boolean active;

	private Set<GradeWrapper> grades = new HashSet<>();

	private Date createdDate;

	private Date updatedDate;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemDesc() {
		return itemDesc;
	}

	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public Set<GradeWrapper> getGrades() {
		return grades;
	}

	public void setGrades(Set<GradeWrapper> grades) {
		this.grades = grades;
	}

	public ItemWrapper() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "ItemWrapper [id=" + id + ", itemName=" + itemName + ", itemDesc=" + itemDesc + ", active=" + active
				+ ", grades=" + grades + ", createdDate=" + createdDate + ", updatedDate=" + updatedDate + "]";
	}

	
}
