package com.erp.common.wrapper.model;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by Harshad on 24/06/2018.
 */


public class MenuWrapper implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	private long id;

	
	private String menuName;

	
	private String menuDesc;
	

	private String menuAction;
	

	private boolean active;
	

    private Set<RoleWrapper> roles = new HashSet<>();

	
	private Date createdDate;

	
	private Date updatedDate;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	
	

	

	public String getMenuName() {
		return menuName;
	}

	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}

	public String getMenuDesc() {
		return menuDesc;
	}

	public void setMenuDesc(String menuDesc) {
		this.menuDesc = menuDesc;
	}

	public String getMenuAction() {
		return menuAction;
	}

	public void setMenuAction(String menuAction) {
		this.menuAction = menuAction;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	

	public Set<RoleWrapper> getRoles() {
		return roles;
	}

	public void setRoles(Set<RoleWrapper> roles) {
		this.roles = roles;
	}

	public MenuWrapper() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "MenuWrapper [id=" + id + ", menuName=" + menuName + ", menuDesc=" + menuDesc + ", menuAction="
				+ menuAction + ", active=" + active + ", createdDate=" + createdDate + ", updatedDate=" + updatedDate
				+ "]";
	}

	

	


}
