package com.erp.common.wrapper.model;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by Harshad on 24/06/2018.
 */

public class UnitWrapper implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private long id;

	private String unitName;

	private String unitDesc;

	private boolean active;

	private Set<GradeWrapper> grades = new HashSet<>();

	private Date createdDate;

	private Date updatedDate;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	public String getUnitDesc() {
		return unitDesc;
	}

	public void setUnitDesc(String unitDesc) {
		this.unitDesc = unitDesc;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public Set<GradeWrapper> getGrades() {
		return grades;
	}

	public void setGrades(Set<GradeWrapper> grades) {
		this.grades = grades;
	}

	public UnitWrapper() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "UnitWrapper [id=" + id + ", unitName=" + unitName + ", unitDesc=" + unitDesc + ", active=" + active
				+ ", grades=" + grades + ", createdDate=" + createdDate + ", updatedDate=" + updatedDate + "]";
	}

	

}
