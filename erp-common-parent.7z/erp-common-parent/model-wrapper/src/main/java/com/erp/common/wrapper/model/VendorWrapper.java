package com.erp.common.wrapper.model;

import java.io.Serializable;
import java.util.Date;


public class VendorWrapper implements Serializable {

	private static final long serialVersionUID = 1L;

	
	private long id;
	
	private String vendorName;
	
	private String vendorNickName;
	
	private String vendorGstNumber;
	
	private VendorTypeWrapper vendorType;
	
	private AddressWrapper address;
	
	private String contactPersonName;
	
	private String contactPersonEmail;
	
	private String contactPersonMobile;
	
	private String contactPersonAlternatePhoneNo;
	
	private String bankAccountNumber;
	
	private String bankBranchIfsc;
	
	private String serviceRenderedGoodsSupplied;
	
	private String bankName;
	
	private String bankBranchName;

	
	private boolean active;

	
	private Date createdDate;

	
	private Date updatedDate;

	public VendorWrapper() {
		super();
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getVendorNickName() {
		return vendorNickName;
	}

	public void setVendorNickName(String vendorNickName) {
		this.vendorNickName = vendorNickName;
	}

	public String getVendorGstNumber() {
		return vendorGstNumber;
	}

	public void setVendorGstNumber(String vendorGstNumber) {
		this.vendorGstNumber = vendorGstNumber;
	}

	

	public VendorTypeWrapper getVendorType() {
		return vendorType;
	}

	public void setVendorType(VendorTypeWrapper vendorType) {
		this.vendorType = vendorType;
	}

	public AddressWrapper getAddress() {
		return address;
	}

	public void setAddress(AddressWrapper address) {
		this.address = address;
	}

	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public String getContactPersonEmail() {
		return contactPersonEmail;
	}

	public void setContactPersonEmail(String contactPersonEmail) {
		this.contactPersonEmail = contactPersonEmail;
	}

	public String getContactPersonMobile() {
		return contactPersonMobile;
	}

	public void setContactPersonMobile(String contactPersonMobile) {
		this.contactPersonMobile = contactPersonMobile;
	}

	public String getContactPersonAlternatePhoneNo() {
		return contactPersonAlternatePhoneNo;
	}

	public void setContactPersonAlternatePhoneNo(String contactPersonAlternatePhoneNo) {
		this.contactPersonAlternatePhoneNo = contactPersonAlternatePhoneNo;
	}

	public String getBankAccountNumber() {
		return bankAccountNumber;
	}

	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	public String getBankBranchIfsc() {
		return bankBranchIfsc;
	}

	public void setBankBranchIfsc(String bankBranchIfsc) {
		this.bankBranchIfsc = bankBranchIfsc;
	}

	public String getServiceRenderedGoodsSupplied() {
		return serviceRenderedGoodsSupplied;
	}

	public void setServiceRenderedGoodsSupplied(String serviceRenderedGoodsSupplied) {
		this.serviceRenderedGoodsSupplied = serviceRenderedGoodsSupplied;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankBranchName() {
		return bankBranchName;
	}

	public void setBankBranchName(String bankBranchName) {
		this.bankBranchName = bankBranchName;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	@Override
	public String toString() {
		return "VendorWrapper [id=" + id + ", vendorName=" + vendorName + ", vendorNickName=" + vendorNickName
				+ ", vendorGstNumber=" + vendorGstNumber + ", vendorType=" + vendorType + ", address=" + address
				+ ", contactPersonName=" + contactPersonName + ", contactPersonEmail=" + contactPersonEmail
				+ ", contactPersonMobile=" + contactPersonMobile + ", contactPersonAlternatePhoneNo="
				+ contactPersonAlternatePhoneNo + ", bankAccountNumber=" + bankAccountNumber + ", bankBranchIfsc="
				+ bankBranchIfsc + ", serviceRenderedGoodsSupplied=" + serviceRenderedGoodsSupplied + ", bankName="
				+ bankName + ", bankBranchName=" + bankBranchName + ", active=" + active + ", createdDate="
				+ createdDate + ", updatedDate=" + updatedDate + "]";
	}
	
	

}
