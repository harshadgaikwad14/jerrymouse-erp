package com.erp.common.wrapper.model;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by Harshad on 24/06/2018.
 */

public class VendorTypeWrapper implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private long id;

	private String typeName;

	private String typeDesc;

	private boolean active;

	private Date createdDate;

	private Date updatedDate;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public String getTypeDesc() {
		return typeDesc;
	}

	public void setTypeDesc(String typeDesc) {
		this.typeDesc = typeDesc;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	

	@Override
	public String toString() {
		return "VendorTypeWrapper [id=" + id + ", typeName=" + typeName + ", typeDesc=" + typeDesc + ", active="
				+ active + ", createdDate=" + createdDate + ", updatedDate=" + updatedDate + "]";
	}

	public VendorTypeWrapper() {
		super();
		// TODO Auto-generated constructor stub
	}

}
