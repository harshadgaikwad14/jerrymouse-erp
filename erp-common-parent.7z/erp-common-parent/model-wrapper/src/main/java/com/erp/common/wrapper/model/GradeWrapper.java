package com.erp.common.wrapper.model;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by Harshad on 24/06/2018.
 */

public class GradeWrapper implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private long id;

	private String gradeName;

	private String gradeDesc;

	private boolean active;

	private Date createdDate;

	private Date updatedDate;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getGradeName() {
		return gradeName;
	}

	public void setGradeName(String gradeName) {
		this.gradeName = gradeName;
	}

	public String getGradeDesc() {
		return gradeDesc;
	}

	public void setGradeDesc(String gradeDesc) {
		this.gradeDesc = gradeDesc;
	}

	public boolean isActive() {
		return active;
	}

	private Set<ItemWrapper> items = new HashSet<>();

	private Set<UnitWrapper> units = new HashSet<>();

	public void setActive(boolean active) {
		this.active = active;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public Set<ItemWrapper> getItems() {
		return items;
	}

	public void setItems(Set<ItemWrapper> items) {
		this.items = items;
	}

	public Set<UnitWrapper> getUnits() {
		return units;
	}

	public void setUnits(Set<UnitWrapper> units) {
		this.units = units;
	}

	public GradeWrapper() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "GradeWrapper [id=" + id + ", gradeName=" + gradeName + ", gradeDesc=" + gradeDesc + ", active=" + active
				+ ", createdDate=" + createdDate + ", updatedDate=" + updatedDate + ", items=" + items + ", units="
				+ units + "]";
	}

	

}
