package com.erp.common.wrapper.model;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;



public class RoleWrapper implements Serializable {

	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private long id;

	private String roleName;

	private boolean active;
	
	private Set<MenuWrapper> menus = new HashSet<>();

	private Date createdDate;

	private Date updatedDate;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public Set<MenuWrapper> getMenus() {
		return menus;
	}

	public void setMenus(Set<MenuWrapper> menus) {
		this.menus = menus;
	}

	@Override
	public String toString() {
		return "RoleWrapper [id=" + id + ", roleName=" + roleName + ", active=" + active + ", menus=" + menus
				+ ", createdDate=" + createdDate + ", updatedDate=" + updatedDate + "]";
	}
	
	

}
