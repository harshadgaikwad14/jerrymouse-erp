package com.erp.util;

public class Constants {
	
	
	private static final String URL = "http://localhost:8080/api/";
	private static final String ADDRESS_ID_BASED_OPERATION=URL+"address/{id}"; // USED FOR UPDATE,DELETE,GETBYID OPERATION
	private static final String GET_ALL_ADDRESSES=URL+"address";
	private static final String CREATE_ADDRESS=URL+"address";



}
