package com.erp.action.api.service;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erp.action.api.exception.ResourceNotFoundException;
import com.erp.action.api.model.Vendor;
import com.erp.action.api.repository.VendorRepository;
import com.erp.action.api.service.transformer.TransformToSetVendorWrapper;
import com.erp.action.api.service.transformer.TransformToVendor;
import com.erp.action.api.service.transformer.TransformToVendorWrapper;
import com.erp.common.wrapper.model.VendorWrapper;

@Service
public class VendorServiceImpl implements VendorService {

	@Autowired
	private VendorRepository vendorRepository;

	@Autowired
	private TransformToVendor transformToVendor;

	@Autowired
	private TransformToVendorWrapper transformToVendorWrapper;

	@Autowired
	TransformToSetVendorWrapper transformToSetVendorWrapper;

	@Override
	public void deleteVendor(long vendorId) {
		Vendor g = vendorRepository.findById(vendorId)
				.orElseThrow(() -> new ResourceNotFoundException("Vendor", "id", vendorId));

		vendorRepository.delete(g);

	}

	@Override
	public void enableDisableVendor(long vendorId, boolean isActive) {
		// TODO Auto-generated method stub

	}

	@Override
	public VendorWrapper createVendor(VendorWrapper vendorWrapper) {

		Vendor vendor = transformToVendor.transform(vendorWrapper, new Vendor());

		transformToVendorWrapper.transform(vendorRepository.save(vendor), vendorWrapper);

		return vendorWrapper;

	}

	@Override
	public VendorWrapper getVendorById(final long vendorId) {
		VendorWrapper vendorWrapper = new VendorWrapper();
		Optional<Vendor> vendor = vendorRepository.findById(vendorId);
		vendorWrapper = transformToVendorWrapper.transform(vendor.get(), vendorWrapper);
		return vendorWrapper;
	}

	@Override
	public void updateVendor(long vendorId, final VendorWrapper vendorWrapper) {
		Optional<Vendor> optional = vendorRepository.findById(vendorId);

		if (optional.isPresent() && optional.get().getId() == vendorWrapper.getId()) {
			Vendor vendor = transformToVendor.transform(vendorWrapper, new Vendor());

			vendorRepository.save(vendor);

		}

	}

	@Override
	public Set<VendorWrapper> findAllVendors() {
		Set<VendorWrapper> vendorWrappers = new HashSet<>();
		List<Vendor> vendors = (List<Vendor>) vendorRepository.findAll();
		vendorWrappers = transformToSetVendorWrapper.transform(new HashSet<>(vendors), vendorWrappers);
		return vendorWrappers;
	}

}
