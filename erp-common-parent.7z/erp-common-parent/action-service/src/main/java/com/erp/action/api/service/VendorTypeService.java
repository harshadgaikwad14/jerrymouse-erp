package com.erp.action.api.service;

import java.util.List;

import com.erp.common.wrapper.model.VendorTypeWrapper;

public interface VendorTypeService {
	
	public VendorTypeWrapper createVendorType(final VendorTypeWrapper vendorTypeWrapper);
	public List<VendorTypeWrapper> findAllVendorTypes();
	public VendorTypeWrapper getVendorTypeById(final long vendorTypeId);
	public void updateVendorType(final long vendorTypeId,final VendorTypeWrapper vendorTypeWrapper);
	public void deleteVendorType(final long vendorTypeId);
	public void enableDisableVendorType(final long vendorTypeId,final boolean flag );

}
