package com.erp.action.api.service.transformer;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.erp.action.api.model.Vendor;
import com.erp.common.wrapper.model.AddressWrapper;
import com.erp.common.wrapper.model.VendorTypeWrapper;
import com.erp.common.wrapper.model.VendorWrapper;

@Component
public class TransformToSetVendorWrapper implements Transformer<Set<Vendor>, Set<VendorWrapper>> {

	@Autowired
	private TransformToVendorTypeWrapper transformToVendorTypeWrapper;
	
	@Autowired
	private TransformToAddressWrapper transformToAddressWrapper;

	@Override
	public Set<VendorWrapper> transform(Set<Vendor> input, Set<VendorWrapper> output) {

		for (Vendor vendor : input) {
			VendorWrapper vendorWrapper = new VendorWrapper();
			vendorWrapper.setId(vendor.getId());
			vendorWrapper.setVendorName(vendor.getVendorName());
			vendorWrapper.setVendorNickName(vendor.getVendorNickName());
			vendorWrapper.setVendorGstNumber(vendor.getVendorGstNumber());
			
			VendorTypeWrapper vendorType = new VendorTypeWrapper();
			vendorType = transformToVendorTypeWrapper.transform(vendor.getVendorType(), vendorType);
			vendorWrapper.setVendorType(vendorType);
			
			AddressWrapper address = new AddressWrapper();
			address = transformToAddressWrapper.transform(vendor.getAddress(), address);
			vendorWrapper.setAddress(address);
			
			vendorWrapper.setContactPersonName(vendor.getContactPersonName());
			vendorWrapper.setContactPersonEmail(vendor.getContactPersonEmail());
			vendorWrapper.setContactPersonMobile(vendor.getContactPersonMobile());
			vendorWrapper.setContactPersonAlternatePhoneNo(vendor.getContactPersonAlternatePhoneNo());
			vendorWrapper.setBankAccountNumber(vendor.getBankAccountNumber());
			vendorWrapper.setBankBranchIfsc(vendor.getBankBranchIfsc());
			vendorWrapper.setServiceRenderedGoodsSupplied(vendor.getServiceRenderedGoodsSupplied());
			vendorWrapper.setBankName(vendor.getBankName());
			vendorWrapper.setBankBranchName(vendor.getBankBranchName());
			vendorWrapper.setActive(vendor.isActive());
			vendorWrapper.setCreatedDate(vendor.getCreatedDate());
			vendorWrapper.setUpdatedDate(vendor.getUpdatedDate());
			output.add(vendorWrapper);
		}

		return output;
	}

}
