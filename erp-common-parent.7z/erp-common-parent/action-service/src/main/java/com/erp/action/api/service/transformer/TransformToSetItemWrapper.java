package com.erp.action.api.service.transformer;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.erp.action.api.model.Item;
import com.erp.common.wrapper.model.GradeWrapper;
import com.erp.common.wrapper.model.ItemWrapper;

@Component
public class TransformToSetItemWrapper implements Transformer<Set<Item>, Set<ItemWrapper>> {

	@Autowired
	private TransformToSetGradeWrapper transformToSetGradeWrapper;

	@Override
	public Set<ItemWrapper> transform(Set<Item> input, Set<ItemWrapper> output) {

		for (Item item : input) {
			ItemWrapper itemWrapper = new ItemWrapper();
			itemWrapper.setId(item.getId());
			itemWrapper.setActive(item.isActive());
			itemWrapper.setItemName(item.getItemName());
			itemWrapper.setItemDesc(item.getItemDesc());
			Set<GradeWrapper> grades = new HashSet<GradeWrapper>();

			grades = transformToSetGradeWrapper.transform(item.getGrades(), grades);
			itemWrapper.setGrades(grades);
			itemWrapper.setCreatedDate(item.getCreatedDate());
			itemWrapper.setUpdatedDate(item.getUpdatedDate());
			output.add(itemWrapper);
		}

		return output;
	}

}
