package com.erp.action.api.service.transformer;

public interface Transformer<I,O> 
{
	
	public O transform(final I input, final O output);
	

}
