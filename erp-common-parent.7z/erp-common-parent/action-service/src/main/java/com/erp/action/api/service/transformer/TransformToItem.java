package com.erp.action.api.service.transformer;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.erp.action.api.model.Grade;
import com.erp.action.api.model.Item;
import com.erp.common.wrapper.model.ItemWrapper;

@Component
public class TransformToItem implements Transformer<ItemWrapper, Item> {

	@Autowired
	private TransformToSetGrade transformToSetGrade;

	@Override
	public Item transform(final ItemWrapper itemWrapper, final Item item) {

		item.setId(itemWrapper.getId());
		item.setActive(itemWrapper.isActive());
		item.setItemName(itemWrapper.getItemName());
		item.setItemDesc(itemWrapper.getItemDesc());
		Set<Grade> grades = new HashSet<Grade>();

		grades = transformToSetGrade.transform(itemWrapper.getGrades(), grades);
		item.setGrades(grades);
		item.setCreatedDate(itemWrapper.getCreatedDate());
		item.setUpdatedDate(itemWrapper.getUpdatedDate());

		return item;
	}

}
