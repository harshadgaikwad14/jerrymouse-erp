package com.erp.action.api.service;



import java.util.Set;

import com.erp.common.wrapper.model.GradeWrapper;



public interface GradeService {
	
	public GradeWrapper createGrade( GradeWrapper GradeWrapper);
	public Set<GradeWrapper> findAllGrades();
	public GradeWrapper getGradeById(final long gradeId);
	public void updateGrade(final long gradeId,final GradeWrapper grade);
	public void deleteGrade(final long grade);
	public void enableDisableGrade(final long gradeId,final boolean isActive );

}
