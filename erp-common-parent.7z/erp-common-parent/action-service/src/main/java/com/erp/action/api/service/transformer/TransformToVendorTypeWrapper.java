package com.erp.action.api.service.transformer;

import org.springframework.stereotype.Component;

import com.erp.action.api.model.VendorType;
import com.erp.common.wrapper.model.VendorTypeWrapper;
@Component
public  class TransformToVendorTypeWrapper implements Transformer<VendorType,VendorTypeWrapper> {

	@Override
	public VendorTypeWrapper transform(final VendorType vendorType, final VendorTypeWrapper vendorTypeWrapper) {
	
		vendorTypeWrapper.setId(vendorType.getId());
		vendorTypeWrapper.setActive(vendorType.isActive());
		vendorTypeWrapper.setTypeName(vendorType.getTypeName());
		vendorTypeWrapper.setTypeDesc(vendorType.getTypeDesc());
		vendorTypeWrapper.setCreatedDate(vendorType.getCreatedDate());
		vendorTypeWrapper.setUpdatedDate(vendorType.getUpdatedDate());
		return vendorTypeWrapper;
	}

	



	

	

}
