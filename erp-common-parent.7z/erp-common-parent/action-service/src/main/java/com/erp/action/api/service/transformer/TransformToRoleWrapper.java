package com.erp.action.api.service.transformer;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.erp.action.api.model.Role;
import com.erp.common.wrapper.model.MenuWrapper;
import com.erp.common.wrapper.model.RoleWrapper;

@Component
public class TransformToRoleWrapper implements Transformer<Role, RoleWrapper> {

	@Autowired
	private TransformToSetMenuWrapper transformToSetMenuWrapper;

	@Override
	public RoleWrapper transform(final Role role, final RoleWrapper roleWrapper) {

		roleWrapper.setId(role.getId());
		roleWrapper.setActive(role.isActive());
		roleWrapper.setRoleName(role.getRoleName());
		Set<MenuWrapper> menus = new HashSet<MenuWrapper>();
		menus = transformToSetMenuWrapper.transform(role.getMenus(), menus);
		roleWrapper.setMenus(menus);
		roleWrapper.setCreatedDate(role.getCreatedDate());
		roleWrapper.setUpdatedDate(role.getUpdatedDate());
		return roleWrapper;
	}

}
