package com.erp.action.api.service.transformer;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.erp.action.api.model.Item;
import com.erp.common.wrapper.model.GradeWrapper;
import com.erp.common.wrapper.model.ItemWrapper;

@Component
public class TransformToItemWrapper implements Transformer<Item, ItemWrapper> {
	@Autowired
	private TransformToSetGradeWrapper transformToSetGradeWrapper;

	@Override
	public ItemWrapper transform(final Item item, final ItemWrapper itemWrapper) {

		itemWrapper.setId(item.getId());
		itemWrapper.setActive(item.isActive());
		itemWrapper.setItemName(item.getItemName());
		itemWrapper.setItemDesc(item.getItemDesc());
		Set<GradeWrapper> grades = new HashSet<GradeWrapper>();

		grades = transformToSetGradeWrapper.transform(item.getGrades(), grades);
		itemWrapper.setGrades(grades);
		itemWrapper.setCreatedDate(item.getCreatedDate());
		itemWrapper.setUpdatedDate(item.getUpdatedDate());
		return itemWrapper;
	}

}
