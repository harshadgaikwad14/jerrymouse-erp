package com.erp.action.api.service;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erp.action.api.exception.ResourceNotFoundException;
import com.erp.action.api.model.Item;
import com.erp.action.api.repository.ItemRepository;
import com.erp.action.api.service.transformer.TransformToItem;
import com.erp.action.api.service.transformer.TransformToItemWrapper;
import com.erp.action.api.service.transformer.TransformToSetItemWrapper;
import com.erp.common.wrapper.model.ItemWrapper;

@Service
public class ItemServiceImpl implements ItemService {

	@Autowired
	private ItemRepository itemRepository;

	@Autowired
	private TransformToItem transformToItem;
	@Autowired
	private TransformToItemWrapper transformToItemWrapper;

	@Autowired
	TransformToSetItemWrapper transformToSetItemWrapper;

	@Override
	public void deleteItem(long itemId) {
		Item i = itemRepository.findById(itemId).orElseThrow(() -> new ResourceNotFoundException("Item", "id", itemId));

		itemRepository.delete(i);

	}

	@Override
	public void enableDisableItem(long ItemId, boolean isActive) {
		// TODO Auto-generated method stub

	}

	@Override
	public ItemWrapper createItem(ItemWrapper itemWrapper) {
		Item item = transformToItem.transform(itemWrapper, new Item());

		transformToItemWrapper.transform(itemRepository.save(item), itemWrapper);

		return itemWrapper;
	}

	@Override
	public ItemWrapper getItemById(long itemId) {

		ItemWrapper itemWrapper = new ItemWrapper();

		Optional<Item> item = itemRepository.findById(itemId);
		itemWrapper = transformToItemWrapper.transform(item.get(), itemWrapper);
		return itemWrapper;
	}

	@Override
	public void updateItem(long itemId, ItemWrapper itemWrapper) {

		Optional<Item> optional = itemRepository.findById(itemId);

		if (optional.isPresent() && optional.get().getId() == itemWrapper.getId()) {
			Item item = transformToItem.transform(itemWrapper, new Item());

			itemRepository.save(item);

		}

	}

	@Override
	public Set<ItemWrapper> findAllItems() {
		Set<ItemWrapper> itemWrapper = new HashSet<>();
		List<Item> items = (List<Item>) itemRepository.findAll();
		itemWrapper = transformToSetItemWrapper.transform(new HashSet<>(items), itemWrapper);
		return itemWrapper;
	}

}
