package com.erp.action.api.service.transformer;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.erp.action.api.model.Unit;
import com.erp.common.wrapper.model.UnitWrapper;

@Component
public class TransformToSetUnit implements Transformer<Set<UnitWrapper>, Set<Unit>> {
	
	@Autowired
	TransformToSetGrade transformToSetGrade;

	@Override
	public Set<Unit> transform(Set<UnitWrapper> input, Set<Unit> output) {

		for (UnitWrapper unitWrapper : input) {
			Unit unit = new Unit();
			unit.setId(unitWrapper.getId());
			unit.setActive(unitWrapper.isActive());
			unit.setUnitName(unitWrapper.getUnitName());
			unit.setUnitDesc(unitWrapper.getUnitDesc());
			
			
			unit.setCreatedDate(unitWrapper.getCreatedDate());
			unit.setUpdatedDate(unitWrapper.getUpdatedDate());
			output.add(unit);
		}

		return output;
	}

}
