package com.erp.action.api.service.transformer;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.erp.action.api.model.Grade;
import com.erp.common.wrapper.model.GradeWrapper;
import com.erp.common.wrapper.model.UnitWrapper;
@Component
public  class TransformToGradeWrapper implements Transformer<Grade,GradeWrapper> {
	
	@Autowired
	private TransformToSetUnitWrapper transformToSetUnitWrapper;
	
	

	@Override
	public GradeWrapper transform(final Grade grade, final GradeWrapper gradeWrapper) {
	
		gradeWrapper.setId(grade.getId());
		gradeWrapper.setActive(grade.isActive());
		gradeWrapper.setGradeName(grade.getGradeName());
		gradeWrapper.setGradeDesc(grade.getGradeDesc());
		
		/*Set<ItemWrapper> items = new HashSet<ItemWrapper>();
		items= transformToSetItemWrapper.transform(grade.getItems(),items);
		gradeWrapper.setItems(items);*/
		
		Set<UnitWrapper> units = new HashSet<UnitWrapper>();
		units= transformToSetUnitWrapper.transform(grade.getUnits(),units);
		gradeWrapper.setUnits(units);
		
		gradeWrapper.setCreatedDate(grade.getCreatedDate());
		gradeWrapper.setUpdatedDate(grade.getUpdatedDate());
		return gradeWrapper;
	}

	



	

	

}
