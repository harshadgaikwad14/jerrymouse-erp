package com.erp.action.api.service;

import java.util.Set;

import com.erp.common.wrapper.model.ItemWrapper;



public interface ItemService {
	
	public ItemWrapper createItem(final  ItemWrapper itemWrapper);
	public Set<ItemWrapper> findAllItems();
	public ItemWrapper getItemById(final long itemId);
	public void updateItem(final long itemId,final ItemWrapper itemWrapper);
	public void deleteItem(final long item);
	public void enableDisableItem(final long itemId,final boolean isActive );

}
