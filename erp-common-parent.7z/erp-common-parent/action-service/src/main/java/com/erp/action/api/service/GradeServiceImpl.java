package com.erp.action.api.service;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erp.action.api.exception.ResourceNotFoundException;
import com.erp.action.api.model.Grade;
import com.erp.action.api.repository.GradeRepository;
import com.erp.action.api.service.transformer.TransformToGrade;
import com.erp.action.api.service.transformer.TransformToGradeWrapper;
import com.erp.action.api.service.transformer.TransformToSetGradeWrapper;
import com.erp.common.wrapper.model.GradeWrapper;

@Service
public class GradeServiceImpl implements GradeService {

	@Autowired
	private GradeRepository gradeRepository;

	@Autowired
	private TransformToGrade transformToGrade;
	@Autowired
	private TransformToGradeWrapper transformToGradeWrapper;

	@Autowired
	private TransformToSetGradeWrapper transformToSetGradeWrapper;

	@Override
	public void deleteGrade(long gradeId) {
		Grade g = gradeRepository.findById(gradeId)
				.orElseThrow(() -> new ResourceNotFoundException("Grade", "id", gradeId));

		gradeRepository.delete(g);

	}

	@Override
	public void enableDisableGrade(long gradeId, boolean isActive) {
		// TODO Auto-generated method stub

	}

	@Override
	public GradeWrapper createGrade(GradeWrapper gradeWrapper) {
		Grade grade = transformToGrade.transform(gradeWrapper, new Grade());

		transformToGradeWrapper.transform(gradeRepository.save(grade), gradeWrapper);

		return gradeWrapper;
	}

	@Override
	public Set<GradeWrapper> findAllGrades() {
		Set<GradeWrapper> gradeWrapper = new HashSet<>();
		List<Grade> grades = (List<Grade>) gradeRepository.findAll();
		gradeWrapper = transformToSetGradeWrapper.transform(new HashSet<>(grades), gradeWrapper);
		return gradeWrapper;
	}

	@Override
	public GradeWrapper getGradeById(final long gradeId) {
		GradeWrapper gradeWrapper = new GradeWrapper();

		Optional<Grade> grade = gradeRepository.findById(gradeId);
		gradeWrapper = transformToGradeWrapper.transform(grade.get(), gradeWrapper);
		return gradeWrapper;
	}

	@Override
	public void updateGrade(final long gradeId, final GradeWrapper gradeWrapper) {

		Optional<Grade> optional = gradeRepository.findById(gradeId);

		if (optional.isPresent() && optional.get().getId() == gradeWrapper.getId()) {
			Grade grade = transformToGrade.transform(gradeWrapper, new Grade());

			gradeRepository.save(grade);

		}

	}

}
