package com.erp.action.api.service.transformer;

import org.springframework.stereotype.Component;

import com.erp.action.api.model.VendorType;
import com.erp.common.wrapper.model.VendorTypeWrapper;

@Component
public class TransformToVendorType implements Transformer<VendorTypeWrapper, VendorType> {

	@Override
	public VendorType transform(final VendorTypeWrapper vendorTypeWrapper, final VendorType vendorType) {

		vendorType.setId(vendorTypeWrapper.getId());
		vendorType.setActive(vendorTypeWrapper.isActive());
		vendorType.setTypeName(vendorTypeWrapper.getTypeName());
		vendorType.setTypeDesc(vendorTypeWrapper.getTypeDesc());
		vendorType.setCreatedDate(vendorTypeWrapper.getCreatedDate());
		vendorType.setUpdatedDate(vendorTypeWrapper.getUpdatedDate());

		return vendorType;
	}

}
