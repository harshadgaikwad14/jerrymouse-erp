package com.erp.action.api.service.transformer;

import org.springframework.stereotype.Component;

import com.erp.action.api.model.Menu;
import com.erp.common.wrapper.model.MenuWrapper;

@Component
public class TransformToMenu implements Transformer<MenuWrapper, Menu> {

	@Override
	public Menu transform(final MenuWrapper menuWrapper, final Menu menu) {

		menu.setId(menuWrapper.getId());
		menu.setActive(menuWrapper.isActive());
		menu.setMenuName(menuWrapper.getMenuName());
		menu.setMenuAction(menuWrapper.getMenuAction());
		menu.setCreatedDate(menuWrapper.getCreatedDate());
		menu.setUpdatedDate(menuWrapper.getUpdatedDate());

		return menu;
	}

}
