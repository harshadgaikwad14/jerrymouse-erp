package com.erp.action.api.service.transformer;

import org.springframework.stereotype.Component;

import com.erp.action.api.model.Menu;
import com.erp.common.wrapper.model.MenuWrapper;
@Component
public  class TransformToMenuWrapper implements Transformer<Menu,MenuWrapper> {

	@Override
	public MenuWrapper transform(final Menu menu, final MenuWrapper menuWrapper) {
	
		menuWrapper.setId(menu.getId());
		menuWrapper.setActive(menu.isActive());
		menuWrapper.setMenuName(menu.getMenuName());
		menuWrapper.setMenuAction(menu.getMenuAction());
		menuWrapper.setCreatedDate(menu.getCreatedDate());
		menuWrapper.setUpdatedDate(menu.getUpdatedDate());
		return menuWrapper;
	}

	



	

	

}
