package com.erp.action.api.service.transformer;

import org.springframework.stereotype.Component;

import com.erp.action.api.model.Unit;
import com.erp.common.wrapper.model.UnitWrapper;
@Component
public  class TransformToUnitWrapper implements Transformer<Unit,UnitWrapper> {

	
	
	@Override
	public UnitWrapper transform(final Unit unit, final UnitWrapper unitWrapper) {
	
		unitWrapper.setId(unit.getId());
		unitWrapper.setActive(unit.isActive());
		unitWrapper.setUnitName(unit.getUnitName());
		unitWrapper.setUnitDesc(unit.getUnitDesc());
	
		unitWrapper.setCreatedDate(unit.getCreatedDate());
		unitWrapper.setUpdatedDate(unit.getUpdatedDate());
		return unitWrapper;
	}

	



	

	

}
