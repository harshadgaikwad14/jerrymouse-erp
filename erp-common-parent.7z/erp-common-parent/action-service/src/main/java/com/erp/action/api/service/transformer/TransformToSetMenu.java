package com.erp.action.api.service.transformer;

import java.util.Set;

import org.springframework.stereotype.Component;

import com.erp.action.api.model.Menu;
import com.erp.common.wrapper.model.MenuWrapper;

@Component
public class TransformToSetMenu implements Transformer<Set<MenuWrapper>, Set<Menu>> {

	@Override
	public Set<Menu> transform(Set<MenuWrapper> input, Set<Menu> output) {

		for (MenuWrapper menuWrapper : input) {
			Menu menu = new Menu();
			menu.setId(menuWrapper.getId());
			menu.setActive(menuWrapper.isActive());
			menu.setMenuName(menuWrapper.getMenuName());
			menu.setMenuAction(menuWrapper.getMenuAction());
			menu.setCreatedDate(menuWrapper.getCreatedDate());
			menu.setUpdatedDate(menuWrapper.getUpdatedDate());

			output.add(menu);
		}

		return output;
	}

}
