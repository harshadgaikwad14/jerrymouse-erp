package com.erp.action.api.service;

import java.util.Set;

import com.erp.common.wrapper.model.VendorWrapper;



public interface VendorService {
	
	public VendorWrapper createVendor(final VendorWrapper vendor);
	public Set<VendorWrapper> findAllVendors();
	public VendorWrapper getVendorById(final long vendorId);
	public void updateVendor(final long vendorId,final VendorWrapper vendorWrapper);
	public void deleteVendor(final long vendorId);
	public void enableDisableVendor(final long vendorId,final boolean isActive );
	

}
