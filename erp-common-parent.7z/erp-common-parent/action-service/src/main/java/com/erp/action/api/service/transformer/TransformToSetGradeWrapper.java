package com.erp.action.api.service.transformer;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.erp.action.api.model.Grade;
import com.erp.common.wrapper.model.GradeWrapper;
import com.erp.common.wrapper.model.UnitWrapper;

@Component
public class TransformToSetGradeWrapper implements Transformer<Set<Grade>, Set<GradeWrapper>> {
	
	@Autowired
	private TransformToSetUnitWrapper transformToSetUnitWrapper;
	
	

	@Override
	public Set<GradeWrapper> transform(Set<Grade> input, Set<GradeWrapper> output) {

		for (Grade grade : input) {
			GradeWrapper gradeWrapper = new GradeWrapper();
			gradeWrapper.setId(grade.getId());
			gradeWrapper.setActive(grade.isActive());
			gradeWrapper.setGradeName(grade.getGradeName());
			gradeWrapper.setGradeDesc(grade.getGradeDesc());
			
			
			
			Set<UnitWrapper> units = new HashSet<UnitWrapper>();
			units= transformToSetUnitWrapper.transform(grade.getUnits(),units);
			gradeWrapper.setUnits(units);
			
			gradeWrapper.setCreatedDate(grade.getCreatedDate());
			gradeWrapper.setUpdatedDate(grade.getUpdatedDate());
			output.add(gradeWrapper);
		}

		return output;
	}

}
