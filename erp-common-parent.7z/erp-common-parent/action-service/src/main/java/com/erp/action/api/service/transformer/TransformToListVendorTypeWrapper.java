package com.erp.action.api.service.transformer;

import java.util.List;

import org.springframework.stereotype.Component;

import com.erp.action.api.model.VendorType;
import com.erp.common.wrapper.model.VendorTypeWrapper;

@Component
public class TransformToListVendorTypeWrapper implements Transformer<List<VendorType>, List<VendorTypeWrapper>> {

	@Override
	public List<VendorTypeWrapper> transform(List<VendorType> input, List<VendorTypeWrapper> output) {

		for (VendorType vendorType : input) {
			VendorTypeWrapper vendorTypeWrapper = new VendorTypeWrapper();
			vendorTypeWrapper.setId(vendorType.getId());
			vendorTypeWrapper.setActive(vendorType.isActive());
			vendorTypeWrapper.setTypeName(vendorType.getTypeName());
			vendorTypeWrapper.setTypeDesc(vendorType.getTypeDesc());
			vendorTypeWrapper.setCreatedDate(vendorType.getCreatedDate());
			vendorTypeWrapper.setUpdatedDate(vendorType.getUpdatedDate());
			output.add(vendorTypeWrapper);
		}
		return output;
	}

}
