package com.erp.action.api.service.transformer;

import org.springframework.stereotype.Component;

import com.erp.action.api.model.Unit;
import com.erp.common.wrapper.model.UnitWrapper;

@Component
public class TransformToUnit implements Transformer<UnitWrapper, Unit> {
	
	

	@Override
	public Unit transform(final UnitWrapper unitWrapper, final Unit unit) {

		unit.setId(unitWrapper.getId());
		unit.setActive(unitWrapper.isActive());
		unit.setUnitName(unitWrapper.getUnitName());
		unit.setUnitDesc(unitWrapper.getUnitDesc());
		unit.setCreatedDate(unitWrapper.getCreatedDate());
		unit.setUpdatedDate(unitWrapper.getUpdatedDate());

		return unit;
	}

}
