package com.erp.action.api.service.transformer;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.erp.action.api.model.Unit;
import com.erp.common.wrapper.model.UnitWrapper;

@Component
public class TransformToSetUnitWrapper implements Transformer<Set<Unit>, Set<UnitWrapper>> {

	@Autowired
	TransformToSetGradeWrapper transformToSetGradeWrapper;

	@Override
	public Set<UnitWrapper> transform(Set<Unit> input, Set<UnitWrapper> output) {

		for (Unit unit : input) {
			UnitWrapper unitWrapper = new UnitWrapper();
			unitWrapper.setId(unit.getId());
			unitWrapper.setActive(unit.isActive());
			unitWrapper.setUnitName(unit.getUnitName());
			unitWrapper.setUnitDesc(unit.getUnitDesc());
			
			unitWrapper.setCreatedDate(unit.getCreatedDate());
			unitWrapper.setUpdatedDate(unit.getUpdatedDate());
			output.add(unitWrapper);
		}

		return output;
	}

}
