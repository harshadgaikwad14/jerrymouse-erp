package com.erp.action.api.service;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erp.action.api.exception.ResourceNotFoundException;
import com.erp.action.api.model.Menu;
import com.erp.action.api.repository.MenuRepository;
import com.erp.action.api.service.transformer.TransformToSetMenuWrapper;
import com.erp.action.api.service.transformer.TransformToMenu;
import com.erp.action.api.service.transformer.TransformToMenuWrapper;
import com.erp.common.wrapper.model.MenuWrapper;

@Service
public class MenuServiceImpl implements MenuService {

	@Autowired
	private MenuRepository MenuRepository;

	@Autowired
	private TransformToMenu transformToMenu;
	@Autowired
	private TransformToMenuWrapper transformToMenuWrapper;

	@Autowired
	TransformToSetMenuWrapper transformToSetMenuWrapper;

	@Override
	public Set<MenuWrapper> findAllMenus() {
		Set<MenuWrapper> menuWrappers = new HashSet<>();
		List<Menu> menus = (List<Menu>) MenuRepository.findAll();
		menuWrappers = transformToSetMenuWrapper.transform(new HashSet<>(menus), menuWrappers);
		return menuWrappers;
	}

	@Override
	public void deleteMenu(final long menuId) {
		Menu u = MenuRepository.findById(menuId).orElseThrow(() -> new ResourceNotFoundException("Menu", "id", menuId));

		MenuRepository.delete(u);

	}

	@Override
	public void enableDisableMenu(long MenuId, boolean isActive) {
		// TODO Auto-generated method stub

	}

	@Override
	public MenuWrapper createMenu(final MenuWrapper menuWrapper) {

		Menu menu = transformToMenu.transform(menuWrapper, new Menu());

		transformToMenuWrapper.transform(MenuRepository.save(menu), menuWrapper);

		return menuWrapper;
	}

	@Override
	public MenuWrapper getMenuById(final long id) {
		MenuWrapper menuWrapper = new MenuWrapper();

		Optional<Menu> menu = MenuRepository.findById(id);
		menuWrapper = transformToMenuWrapper.transform(menu.get(), menuWrapper);
		return menuWrapper;
	}

	@Override
	public void updateMenu(final long id, final MenuWrapper menuWrapper) {

		Optional<Menu> optional = MenuRepository.findById(id);

		if (optional.isPresent() && optional.get().getId() == menuWrapper.getId()) {
			Menu menu = transformToMenu.transform(menuWrapper, new Menu());

			MenuRepository.save(menu);

		}
	}

}
