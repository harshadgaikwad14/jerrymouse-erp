package com.erp.action.api.service.transformer;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.erp.action.api.model.Menu;
import com.erp.action.api.model.Role;
import com.erp.common.wrapper.model.RoleWrapper;

@Component
public class TransformToRole implements Transformer<RoleWrapper, Role> {
	
	@Autowired
	private TransformToSetMenu transformToSetMenu;

	@Override
	public Role transform(final RoleWrapper roleWrapper, final Role role) {

		role.setId(roleWrapper.getId());
		role.setActive(roleWrapper.isActive());
		role.setRoleName(roleWrapper.getRoleName());
		
		Set<Menu> menus = new HashSet<Menu>();
		menus= transformToSetMenu.transform(roleWrapper.getMenus(),menus);
		
		role.setMenus(menus);
		role.setCreatedDate(roleWrapper.getCreatedDate());
		role.setUpdatedDate(roleWrapper.getUpdatedDate());

		return role;
	}

}
