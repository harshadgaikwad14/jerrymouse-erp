package com.erp.action.api.service;

import java.util.Set;

import com.erp.common.wrapper.model.UnitWrapper;



public interface UnitService {
	
	public UnitWrapper createUnit( UnitWrapper unitWrapper);
	public Set<UnitWrapper> findAllUnits();
	public UnitWrapper getUnitById(final long id);
	public void updateUnit(final long id,final UnitWrapper unitWrapper);
	public void deleteUnit(final long id);
	public void enableDisableUnit(final long id,final boolean isActive );


}
