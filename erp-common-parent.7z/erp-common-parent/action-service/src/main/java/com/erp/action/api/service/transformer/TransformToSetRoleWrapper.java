package com.erp.action.api.service.transformer;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.erp.action.api.model.Role;
import com.erp.common.wrapper.model.MenuWrapper;
import com.erp.common.wrapper.model.RoleWrapper;

@Component
public class TransformToSetRoleWrapper implements Transformer<Set<Role>, Set<RoleWrapper>> {

	@Autowired
	private TransformToSetMenuWrapper transformToSetMenuWrapper;
	@Override
	public Set<RoleWrapper> transform(Set<Role> input, Set<RoleWrapper> output) {

		for (Role role : input) {
			RoleWrapper roleWrapper = new RoleWrapper();
			roleWrapper.setId(role.getId());
			roleWrapper.setActive(role.isActive());
			roleWrapper.setRoleName(role.getRoleName());
			Set<MenuWrapper> menus = new HashSet<MenuWrapper>();
			menus = transformToSetMenuWrapper.transform(role.getMenus(), menus);
			System.out.println("menus : "+menus);
			roleWrapper.setMenus(menus);
			roleWrapper.setCreatedDate(role.getCreatedDate());
			roleWrapper.setUpdatedDate(role.getUpdatedDate());
			output.add(roleWrapper);
		}

		return output;
	}

}
