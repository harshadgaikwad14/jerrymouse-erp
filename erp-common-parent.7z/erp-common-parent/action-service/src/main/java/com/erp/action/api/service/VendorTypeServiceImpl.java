package com.erp.action.api.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erp.action.api.exception.ResourceNotFoundException;
import com.erp.action.api.model.VendorType;
import com.erp.action.api.repository.VendorTypeRepository;
import com.erp.action.api.service.transformer.TransformToListVendorTypeWrapper;
import com.erp.action.api.service.transformer.TransformToVendorType;
import com.erp.action.api.service.transformer.TransformToVendorTypeWrapper;
import com.erp.common.wrapper.model.VendorTypeWrapper;

@Service
public class VendorTypeServiceImpl implements VendorTypeService {

	@Autowired
	private VendorTypeRepository vendorTypeRepository;

	@Autowired
	private TransformToVendorType transformToVendorType;

	@Autowired
	private TransformToVendorTypeWrapper transformToVendorTypeWrapper;

	@Autowired
	private TransformToListVendorTypeWrapper transformToListVendorTypeWrapper;

	@Override
	public void deleteVendorType(final long vendorTypeId) {

		VendorType vendorType = vendorTypeRepository.findById(vendorTypeId)
				.orElseThrow(() -> new ResourceNotFoundException("Vendor Type", "id", vendorTypeId));

		vendorTypeRepository.delete(vendorType);

	}

	@Override
	public void enableDisableVendorType(final long vendorTypeId, final boolean flag) {

	}

	@Override
	public VendorTypeWrapper createVendorType(final VendorTypeWrapper vendorTypeWrapper) {

		VendorType vendorType = transformToVendorType.transform(vendorTypeWrapper, new VendorType());

		transformToVendorTypeWrapper.transform(vendorTypeRepository.save(vendorType), vendorTypeWrapper);

		return vendorTypeWrapper;
	}

	@Override
	public VendorTypeWrapper getVendorTypeById(final long vendorTypeId) {

		VendorTypeWrapper vendorTypeWrapper = new VendorTypeWrapper();

		Optional<VendorType> vendorType = vendorTypeRepository.findById(vendorTypeId);
		vendorTypeWrapper = transformToVendorTypeWrapper.transform(vendorType.get(), vendorTypeWrapper);
		return vendorTypeWrapper;
	}

	@Override
	public void updateVendorType(final long vendorTypeId, final VendorTypeWrapper vendorTypeWrapper) {
		Optional<VendorType> optional = vendorTypeRepository.findById(vendorTypeId);

		if(optional.isPresent() && optional.get().getId() == vendorTypeWrapper.getId())
		{
			VendorType add = transformToVendorType.transform(vendorTypeWrapper, new VendorType());
			
			
			vendorTypeRepository.save(add);

		}
	}

	@Override
	public List<VendorTypeWrapper> findAllVendorTypes() {
		List<VendorTypeWrapper> list = new ArrayList<>();
		list = transformToListVendorTypeWrapper.transform((List<VendorType>) vendorTypeRepository.findAll(), list);
		return list;
	}

}
