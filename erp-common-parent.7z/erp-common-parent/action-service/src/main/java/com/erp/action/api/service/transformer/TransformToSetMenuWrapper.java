package com.erp.action.api.service.transformer;

import java.util.Set;

import org.springframework.stereotype.Component;

import com.erp.action.api.model.Menu;
import com.erp.common.wrapper.model.MenuWrapper;

@Component
public class TransformToSetMenuWrapper implements Transformer<Set<Menu>, Set<MenuWrapper>> {

	@Override
	public Set<MenuWrapper> transform(Set<Menu> input, Set<MenuWrapper> output) {

		for (Menu menu : input) {
			System.out.println("menu : "+menu);
			MenuWrapper menuWrapper = new MenuWrapper();
			menuWrapper.setId(menu.getId());
			menuWrapper.setActive(menu.isActive());
			menuWrapper.setMenuName(menu.getMenuName());
			menuWrapper.setMenuAction(menu.getMenuAction());
			menuWrapper.setCreatedDate(menu.getCreatedDate());
			menuWrapper.setUpdatedDate(menu.getUpdatedDate());
			output.add(menuWrapper);
		}

		return output;
	}

}
