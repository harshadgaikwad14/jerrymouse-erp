package com.erp.action.api.service.transformer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.erp.action.api.model.Address;
import com.erp.action.api.model.Vendor;
import com.erp.action.api.model.VendorType;
import com.erp.common.wrapper.model.VendorWrapper;

@Component
public class TransformToVendor implements Transformer<VendorWrapper, Vendor> {
	
	@Autowired
	private TransformToVendorType transformToVendorType;
	
	@Autowired
	private TransformToAddress transformToAddress;

	@Override
	public Vendor transform(final VendorWrapper vendorWrapper, final Vendor vendor) {

		vendor.setId(vendorWrapper.getId());
		vendor.setVendorName(vendorWrapper.getVendorName());
		vendor.setVendorNickName(vendorWrapper.getVendorNickName());
		vendor.setVendorGstNumber(vendorWrapper.getVendorGstNumber());
		
		VendorType vendorType = new VendorType();
		vendorType = transformToVendorType.transform(vendorWrapper.getVendorType(), vendorType);
		vendor.setVendorType(vendorType);
		
		Address address = new Address();
		address = transformToAddress.transform(vendorWrapper.getAddress(), address);
		vendor.setAddress(address);
		
		vendor.setContactPersonName(vendorWrapper.getContactPersonName());
		vendor.setContactPersonEmail(vendorWrapper.getContactPersonEmail());
		vendor.setContactPersonMobile(vendorWrapper.getContactPersonMobile());
		vendor.setContactPersonAlternatePhoneNo(vendorWrapper.getContactPersonAlternatePhoneNo());
		vendor.setBankAccountNumber(vendorWrapper.getBankAccountNumber());
		vendor.setBankBranchIfsc(vendorWrapper.getBankBranchIfsc());
		vendor.setServiceRenderedGoodsSupplied(vendorWrapper.getServiceRenderedGoodsSupplied());
		vendor.setBankName(vendorWrapper.getBankName());
		vendor.setBankBranchName(vendorWrapper.getBankBranchName());
		vendor.setActive(vendorWrapper.isActive());
		vendor.setCreatedDate(vendorWrapper.getCreatedDate());
		vendor.setUpdatedDate(vendorWrapper.getUpdatedDate());

		return vendor;
	}

}
