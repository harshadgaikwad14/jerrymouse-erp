package com.erp.action.api.service.transformer;

import java.util.List;

import org.springframework.stereotype.Component;

import com.erp.action.api.model.VendorType;
import com.erp.common.wrapper.model.VendorTypeWrapper;

@Component
public class TransformToListVendorType implements Transformer<List<VendorTypeWrapper>, List<VendorType>> {

	@Override
	public List<VendorType> transform(List<VendorTypeWrapper> input, List<VendorType> output) {

		for (VendorTypeWrapper vendorTypeWrapper : input) {
			VendorType vendorType = new VendorType();
			vendorType.setId(vendorTypeWrapper.getId());
			vendorType.setActive(vendorTypeWrapper.isActive());
			vendorType.setTypeName(vendorTypeWrapper.getTypeName());
			vendorType.setTypeDesc(vendorTypeWrapper.getTypeDesc());
			vendorType.setCreatedDate(vendorTypeWrapper.getCreatedDate());
			vendorType.setUpdatedDate(vendorTypeWrapper.getUpdatedDate());
			output.add(vendorType);
		}

		return output;
	}

}
