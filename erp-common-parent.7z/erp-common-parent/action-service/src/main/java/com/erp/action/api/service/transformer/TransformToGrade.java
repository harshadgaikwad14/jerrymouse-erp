package com.erp.action.api.service.transformer;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.erp.action.api.model.Grade;
import com.erp.action.api.model.Unit;
import com.erp.common.wrapper.model.GradeWrapper;

@Component
public class TransformToGrade implements Transformer<GradeWrapper, Grade> {

	@Autowired
	private TransformToSetUnit transformToSetUnit;

	@Override
	public Grade transform(final GradeWrapper gradeWrapper, final Grade grade) {

		grade.setId(gradeWrapper.getId());
		grade.setActive(gradeWrapper.isActive());
		grade.setGradeName(gradeWrapper.getGradeName());
		grade.setGradeDesc(gradeWrapper.getGradeDesc());

		Set<Unit> units = new HashSet<Unit>();
		units = transformToSetUnit.transform(gradeWrapper.getUnits(), units);
		grade.setUnits(units);

		grade.setCreatedDate(gradeWrapper.getCreatedDate());
		grade.setUpdatedDate(gradeWrapper.getUpdatedDate());

		return grade;
	}

}
