package com.erp.action.api.service;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erp.action.api.exception.ResourceNotFoundException;
import com.erp.action.api.model.Unit;
import com.erp.action.api.repository.UnitRepository;
import com.erp.action.api.service.transformer.TransformToSetUnitWrapper;
import com.erp.action.api.service.transformer.TransformToUnit;
import com.erp.action.api.service.transformer.TransformToUnitWrapper;
import com.erp.common.wrapper.model.UnitWrapper;

@Service
public class UnitServiceImpl implements UnitService {

	@Autowired
	private UnitRepository unitRepository;

	@Autowired
	private TransformToUnit transformToUnit;
	@Autowired
	private TransformToUnitWrapper transformToUnitWrapper;

	@Autowired
	TransformToSetUnitWrapper transformToSetUnitWrapper;

	@Override
	public Set<UnitWrapper> findAllUnits() {
		Set<UnitWrapper> unitWrappers = new HashSet<>();
		List<Unit> units = (List<Unit>) unitRepository.findAll();
		unitWrappers = transformToSetUnitWrapper.transform(new HashSet<>(units), unitWrappers);
		return unitWrappers;
	}

	@Override
	public void deleteUnit(long unitId) {
		Unit u = unitRepository.findById(unitId).orElseThrow(() -> new ResourceNotFoundException("Unit", "id", unitId));

		unitRepository.delete(u);

	}

	@Override
	public void enableDisableUnit(long unitId, boolean isActive) {
		// TODO Auto-generated method stub

	}

	@Override
	public UnitWrapper createUnit(UnitWrapper unitWrapper) {

		Unit unit = transformToUnit.transform(unitWrapper, new Unit());

		transformToUnitWrapper.transform(unitRepository.save(unit), unitWrapper);

		return unitWrapper;
	}

	@Override
	public UnitWrapper getUnitById(final long id) {
		UnitWrapper unitWrapper = new UnitWrapper();

		Optional<Unit> unit = unitRepository.findById(id);
		unitWrapper = transformToUnitWrapper.transform(unit.get(), unitWrapper);
		return unitWrapper;
	}

	@Override
	public void updateUnit(long id, UnitWrapper unitWrapper) {

		Optional<Unit> optional = unitRepository.findById(id);

		if (optional.isPresent() && optional.get().getId() == unitWrapper.getId()) {
			Unit unit = transformToUnit.transform(unitWrapper, new Unit());

			unitRepository.save(unit);

		}
	}

}
