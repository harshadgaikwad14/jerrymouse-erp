package com.erp.action.api.service;

import java.util.Set;

import com.erp.common.wrapper.model.MenuWrapper;



public interface MenuService {
	
	public MenuWrapper createMenu( MenuWrapper menuWrapper);
	public Set<MenuWrapper> findAllMenus();
	public MenuWrapper getMenuById(final long id);
	public void updateMenu(final long id,final MenuWrapper menuWrapper);
	public void deleteMenu(final long id);
	public void enableDisableMenu(final long id,final boolean isActive );


}
