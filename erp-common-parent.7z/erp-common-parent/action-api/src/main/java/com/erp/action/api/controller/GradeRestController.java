package com.erp.action.api.controller;

import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.erp.action.api.service.GradeService;
import com.erp.common.wrapper.model.GradeWrapper;

/**
 * Created by Harshad on 23/06/2018
 */
@RestController
@RequestMapping("/api")
public class GradeRestController {

	@Autowired
	GradeService gradeService;

	@GetMapping("/grades")
	public Set<GradeWrapper> findAllGrades() {
		return gradeService.findAllGrades();
	}

	@PostMapping("/grades")
	public GradeWrapper createGrade(@RequestBody final GradeWrapper gradeWrapper) {

		return gradeService.createGrade(gradeWrapper);
	}

	@GetMapping("/grades/{id}")
	public GradeWrapper getGradeById(@PathVariable(value = "id") final long gradeId) {
		return gradeService.getGradeById(gradeId);
	}

	@PutMapping("/grades/{id}")
	public ResponseEntity<?> updateGrade(@PathVariable(value = "id") final long gradeId,
			@Valid @RequestBody final GradeWrapper gradeWrapper) {

		gradeService.updateGrade(gradeId, gradeWrapper);
		return ResponseEntity.ok().build();
	}

	@DeleteMapping("/grades/{id}")
	public ResponseEntity<?> deleteGrade(@PathVariable(value = "id") final long gradeId) {
		gradeService.deleteGrade(gradeId);

		return ResponseEntity.ok().build();
	}
}
