package com.erp.action.api.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.erp.action.api.service.VendorTypeService;
import com.erp.common.wrapper.model.VendorTypeWrapper;



/**
 * Created by Harshad on 23/06/2018
 */
@RestController
@RequestMapping("/api")
public class VendorTypeRestController {

	@Autowired
	private VendorTypeService vendorTypeService;

	@GetMapping("/vendorTypes")
	public List<VendorTypeWrapper> findAllVendorTypes() {
		return vendorTypeService.findAllVendorTypes();
	}

	@PostMapping("/vendorTypes")
	public VendorTypeWrapper createVendorType(@RequestBody final VendorTypeWrapper vendorTypeWrapper) {
		
		return vendorTypeService.createVendorType(vendorTypeWrapper);
	}

	@GetMapping("/vendorTypes/{id}")
	public VendorTypeWrapper getVendorTypeById(@PathVariable(value = "id") final long vendorTypeId) {
		return vendorTypeService.getVendorTypeById(vendorTypeId);
	}

	@PutMapping("/vendorTypes/{id}")
	public ResponseEntity<?> updateVendorType(@PathVariable(value = "id") final long vendorTypeId,
			@Valid @RequestBody final VendorTypeWrapper vendorType) {

		 vendorTypeService.updateVendorType(vendorTypeId, vendorType);
		
		return ResponseEntity.ok().build();
	}

	@DeleteMapping("/vendorTypes/{id}")
	public ResponseEntity<?> deleteNote(@PathVariable(value = "id") final long vendorTypeId) {
		vendorTypeService.deleteVendorType(vendorTypeId);

		return ResponseEntity.ok().build();
	}
}
