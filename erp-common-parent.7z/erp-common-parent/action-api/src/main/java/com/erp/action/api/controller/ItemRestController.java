package com.erp.action.api.controller;

import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.erp.action.api.service.ItemService;
import com.erp.common.wrapper.model.ItemWrapper;

/**
 * Created by Harshad on 23/06/2018
 */
@RestController
@RequestMapping("/api")
public class ItemRestController {

	@Autowired
	ItemService itemService;

	@GetMapping("/items")
	public Set<ItemWrapper> findAllItems() {
		return itemService.findAllItems();
	}

	@PostMapping("/items")
	public ItemWrapper createItem(@RequestBody final ItemWrapper itemWrapper) {

		return itemService.createItem(itemWrapper);
	}

	@GetMapping("/items/{id}")
	public ItemWrapper getItemById(@PathVariable(value = "id") final long itemId) {
		return itemService.getItemById(itemId);
	}

	@PutMapping("/items/{id}")
	public ResponseEntity<?> updateItem(@PathVariable(value = "id") final long itemId,
			@Valid @RequestBody ItemWrapper itemWrapper) {

		itemService.updateItem(itemId, itemWrapper);
		return ResponseEntity.ok().build();
	}

	@DeleteMapping("/items/{id}")
	public ResponseEntity<?> deleteItem(@PathVariable(value = "id") final long itemId) {
		itemService.deleteItem(itemId);

		return ResponseEntity.ok().build();
	}
}
