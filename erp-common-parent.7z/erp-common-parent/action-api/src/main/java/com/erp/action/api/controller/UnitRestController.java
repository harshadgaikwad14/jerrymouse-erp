package com.erp.action.api.controller;

import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.erp.action.api.service.UnitService;
import com.erp.common.wrapper.model.UnitWrapper;

/**
 * Created by Harshad on 23/06/2018
 */
@RestController
@RequestMapping("/api")
public class UnitRestController {

	@Autowired
	UnitService unitService;

	@GetMapping("/units")
	public Set<UnitWrapper> findAllUnits() {
		return unitService.findAllUnits();
	}

	@PostMapping("/units")
	public UnitWrapper createUnit(@RequestBody final UnitWrapper unitWrapper) {

		return unitService.createUnit(unitWrapper);
	}

	@GetMapping("/units/{id}")
	public UnitWrapper getUnitById(@PathVariable(value = "id") final long unitId) {
		return unitService.getUnitById(unitId);
	}

	@PutMapping("/units/{id}")
	public ResponseEntity<?> updateUnit(@PathVariable(value = "id") final long unitId,
			@Valid @RequestBody final UnitWrapper unitWrapper) {

		unitService.updateUnit(unitId, unitWrapper);
		return ResponseEntity.ok().build();
	}

	@DeleteMapping("/units/{id}")
	public ResponseEntity<?> deleteUnit(@PathVariable(value = "id") final long unitId) {
		unitService.deleteUnit(unitId);

		return ResponseEntity.ok().build();
	}
}
