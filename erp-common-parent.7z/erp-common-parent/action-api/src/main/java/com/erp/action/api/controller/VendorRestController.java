package com.erp.action.api.controller;

import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.erp.action.api.service.VendorService;
import com.erp.common.wrapper.model.VendorWrapper;

/**
 * Created by Harshad on 23/06/2018
 */
@RestController
@RequestMapping("/api")
public class VendorRestController {

	@Autowired
	VendorService vendorService;

	@GetMapping("/vendors")
	public Set<VendorWrapper> findAllVendors() {
		return vendorService.findAllVendors();
	}

	@PostMapping("/vendors")
	public VendorWrapper createVendor(@RequestBody final VendorWrapper vendorWrapper) {

		return vendorService.createVendor(vendorWrapper);
	}

	@GetMapping("/vendors/{id}")
	public VendorWrapper getVendorById(@PathVariable(value = "id") final long vendorId) {
		return vendorService.getVendorById(vendorId);
	}

	@PutMapping("/vendors/{id}")
	public ResponseEntity<?> updateVendor(@PathVariable(value = "id") final long vendorId, @Valid @RequestBody final  VendorWrapper vendor) {

		vendorService.updateVendor(vendorId, vendor);
		
		return ResponseEntity.ok().build();
	}

	@DeleteMapping("/vendors/{id}")
	public ResponseEntity<?> deleteVendor(@PathVariable(value = "id") final long vendorId) {
		vendorService.deleteVendor(vendorId);

		return ResponseEntity.ok().build();
	}
}
